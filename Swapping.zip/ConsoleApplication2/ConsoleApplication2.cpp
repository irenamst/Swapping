#include <iostream>

using namespace std;
void swapargs(int *x,int *y);
int main()
{
    int g = 10;
    int h = 65;
    int* i = &g;
    int* j = &h;
    *i=10;
    *j=19;
    cout << "i: " << *i << ", ";
    cout << "j: " << *j << "\n";
    swapargs(i,j);
    cout<<"After swapping: ";
    cout<<"i: "<<*i<<", ";
    cout<<"j: "<<*j<<"\n";
    return 0;
}
void swapargs(int *x, int *y){
    int t;
    t=*x;
   *x=*y;
    *y=t;
}
